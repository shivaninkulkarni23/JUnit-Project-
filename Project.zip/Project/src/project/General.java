/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Scanner;

public class General {
  
    Scanner sc=new Scanner(System.in);
    int f=0;
    String s;
    String First,Last,User,Pass,email;
   
     public String getFirst()
        {
        First="Admin";
        if(First.equals("^$")||First.equals("^[1-9]*$"))
        {
            System.out.println("Invalid FirstName");
        }
                
        return First;
        }
     public  String getLast()
        {
        Last="AdminS";
        if(Last.equals("^$")||Last.equals("^[1-9]*$"))
        {
            System.out.println("Invalid LastName");
        }
        return Last;
        }
     public String getUser()
        {
        User="Admin123";
        if(User.equals("^$"))
            System.out.println("Invalid...Username Should have one Uppercase ,Lowercase and one digit");
        //if(User.equals("^[A-Z][a-z]*[1-9]*$"))
        return User;
        }
     public String getPass()
        {
        Pass="Admin@123";
        if(Pass.equals("^$"))
            System.out.println("Invalid...Username Should have one Uppercase ,Lowercase and one digit");
        return Pass;
        }
       
public String getemail()
        {
        email="s@gmail.com";
        if(email.equals("^$"))
            System.out.println("Invalid...");
        return email;
        }
     

    public static void main(String[] args) {
       
    }
}
