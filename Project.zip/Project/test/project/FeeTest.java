/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author me
 */
public class FeeTest {
    Fee f=new Fee();
    public FeeTest() {
        String actual="0";
        String expected="0";
        assertEquals(expected, actual,"0");
        
    }
    
    @BeforeClass
    public static void setUpClass() {
    }

    /**
     * Test of main method, of class Fee.
     */
    @Test
    public void testMain() {
        
    }
    
}
