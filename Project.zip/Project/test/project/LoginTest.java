/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

/**
 *
 * @author me
 */
public class LoginTest {
    
    public LoginTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @Test
    public void testCheck() {
        String Actual="Admin";
        String expected="Admin";
        assertEquals(expected, Actual);
        
    }

    /**
     * Test of main method, of class Login.
     */
    @Test
    public void testMain() {
    }
    
}
