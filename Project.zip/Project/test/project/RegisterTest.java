/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

/**
 *
 * @author me
 */
public class RegisterTest {
    
    General g=new General();

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    /**
     * Test of CheckFirstName method, of class Register.
     */
    
    
    @Test
    public void testCheckFirstName() {
       
        String actual=g.getFirst();
        String expect="Admin";
        assertEquals(expect, actual);
    }

    /**
     * Test of CheckLastName method, of class Register.
     */
    @Test
    public void testCheckLastName() {
        String actual=g.getLast();
        String expect="AdminS";
        assertEquals(expect, actual);
    }

    /**
     * Test of CheckEmail method, of class Register.
     */
    @Test
    public void testCheckEmail() {
        String actual=g.getemail();
        String expect="s@gmail.com";
        assertEquals(expect, actual);
    }

    /**
     * Test of CheckUsername method, of class Register.
     */
    @Test
    public void testCheckUsername() {
        String actual=g.getUser();
        String expect="Admin123";
        assertEquals(expect, actual);

    }

    /**
     * Test of CheckPassword method, of class Register.
     */
    @Test
    public void testCheckPassword() {
        String actual =g.getPass();
        String expect="Admin@123";
         assertEquals(expect, actual);
    }

    /**
     * Test of main method, of class Register.
     */
    @Test
    public void testMain() {
        
    }
    
}
